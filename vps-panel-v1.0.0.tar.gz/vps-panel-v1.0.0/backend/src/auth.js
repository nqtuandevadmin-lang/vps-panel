// auth.js - JWT, bcrypt (cost 12), TOTP 2FA, sessions, API keys, brute-force protection
'use strict';
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const otplib = require('otplib');
const { cfg, secrets } = require('./config');
const db = require('./db');

const ACCESS_OPTS = (extra = {}) => ({ algorithm: 'HS256', expiresIn: cfg.jwtAccessTTL, ...extra });
const REFRESH_OPTS = (extra = {}) => ({ algorithm: 'HS256', expiresIn: cfg.jwtRefreshTTL, ...extra });

async function hashPassword(pw) { return bcrypt.hash(pw, cfg.bcryptCost); }
async function verifyPassword(pw, hash) { return bcrypt.compare(pw, hash || ''); }

function passwordPolicy(pw) {
  const errs = [];
  if (pw.length < cfg.passwordMinLen) errs.push(`min ${cfg.passwordMinLen} chars`);
  if (!/[A-Z]/.test(pw)) errs.push('1 uppercase');
  if (!/[a-z]/.test(pw)) errs.push('1 lowercase');
  if (!/[0-9]/.test(pw)) errs.push('1 digit');
  if (!/[^A-Za-z0-9]/.test(pw)) errs.push('1 symbol');
  return errs;
}
function passwordScore(pw) {
  // zxcvbn-lite: 0..5
  if (!pw) return 0;
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/[0-9]/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  if (/(.)\1{2,}|123456|password|qwerty/i.test(pw)) s = Math.max(0, s - 2);
  return Math.min(5, s);
}

function signAccess(payload) {
  return jwt.sign(payload, secrets.jwtAccess, ACCESS_OPTS());
}
function signRefresh(payload) {
  return jwt.sign(payload, secrets.jwtRefresh, REFRESH_OPTS());
}
function verifyAccess(token) {
  try { return jwt.verify(token, secrets.jwtAccess, { algorithms: ['HS256'] }); } catch { return null; }
}
function verifyRefresh(token) {
  try { return jwt.verify(token, secrets.jwtRefresh, { algorithms: ['HS256'] }); } catch { return null; }
}

// ---------- sessions ----------
function createSession(userId, ip, ua) {
  const raw = crypto.randomBytes(32).toString('hex');
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const s = db.insert('sessions', {
    userId, tokenHash: hash, ip, ua: ua?.slice(0, 255) || '',
    createdAt: Date.now(), expiresAt: Date.now() + cfg.sessionTimeoutMin * 60000, revoked: false,
  });
  return { sessionId: s.id, raw };
}
function validateSession(raw) {
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const s = db.coll('sessions').find(x => x.tokenHash === hash);
  if (!s || s.revoked || s.expiresAt < Date.now()) return null;
  return s;
}
function revokeSession(id) { db.update('sessions', id, { revoked: true }); }
function revokeAllSessions(userId, exceptId) {
  db.coll('sessions').forEach(s => { if (s.userId === userId && s.id !== exceptId) s.revoked = true; });
  db.save();
}
function pruneSessions() {
  const now = Date.now();
  db.coll('sessions').forEach(s => { if (s.expiresAt < now) s.revoked = true; });
  db.save();
}

function validateSessionFromPayload(payload) {
  if (!payload || !payload.sid) return null;
  const s = db.coll('sessions').find(x => x.id === payload.sid);
  if (!s || s.revoked || s.expiresAt < Date.now()) return null;
  return s;
}

// ---------- API keys ----------
function createApiKey(userId, name, role = 'user') {
  const raw = 'vp_' + crypto.randomBytes(24).toString('hex');
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const k = db.insert('apiKeys', { userId, keyHash: hash, name, role, createdAt: Date.now(), lastUsed: null, revoked: false });
  return { keyId: k.id, raw };
}
function validateApiKey(raw) {
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const k = db.coll('apiKeys').find(x => x.keyHash === hash);
  if (!k || k.revoked) return null;
  k.lastUsed = Date.now(); db.save();
  return k;
}

// ---------- 2FA ----------
function generateTotpSecret() { return otplib.authenticator.generateSecret(); }
function totpUri(secret, username) {
  return otplib.authenticator.keyuri(username, 'VPS-Panel', secret);
}
function verifyTotp(secret, token) {
  try { return otplib.authenticator.check(token, secret); } catch { return false; }
}
function generateBackupCodes(n = 8) {
  const codes = [];
  for (let i = 0; i < n; i++) codes.push(crypto.randomBytes(4).toString('hex').toUpperCase().replace(/(.{4})/g, '$1-').slice(0, 9));
  return codes.map(c => crypto.createHash('sha256').update(c).digest('hex'));
}

// ---------- brute force ----------
function checkBruteForce(user) {
  if (!user) return { ok: true };
  if (user.lockedUntil && user.lockedUntil > Date.now()) {
    const mins = Math.ceil((user.lockedUntil - Date.now()) / 60000);
    return { ok: false, locked: true, retryInMin: mins };
  }
  return { ok: true };
}
function recordFailedLogin(user) {
  const fails = (user.failedAttempts || 0) + 1;
  const patch = { failedAttempts: fails };
  if (fails >= cfg.bruteForceMax) patch.lockedUntil = Date.now() + cfg.bruteLockoutMin * 60000;
  db.update('users', user.id, patch);
}
function recordSuccessLogin(user, ip) {
  db.update('users', user.id, { failedAttempts: 0, lockedUntil: 0, lastLogin: Date.now(), lastIp: ip });
}

// ---------- CSRF ----------
function csrfToken(sessionId) {
  return crypto.createHmac('sha256', secrets.csrf).update(sessionId).digest('hex');
}
function verifyCsrf(sessionId, token) {
  if (!sessionId || !token) return false;
  const expect = csrfToken(sessionId);
  return crypto.timingSafeEqual(Buffer.from(expect), Buffer.from(String(token)));
}

// ---------- random admin ----------
// Guarantees the password satisfies passwordPolicy(): at least one upper, lower,
// digit and symbol, regardless of random chance. Cryptographically shuffled.
const PW_CLASSES = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnopqrstuvwxyz', '23456789', '!@#$%&*?-+='];
function randomPassword(len = 18) {
  const len4 = Math.max(8, len);
  const all = PW_CLASSES.join('');
  const pick = (set) => set[crypto.randomInt(set.length)];
  const chars = PW_CLASSES.map(pick); // one from each required class
  while (chars.length < len4) chars.push(pick(all));
  // Fisher-Yates with crypto randomness (no bias, no modulo)
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join('');
}

// ---------- platform identity (multi-tenant) ----------
// Every panel account can be mapped to a real Linux account. The terminal then
// runs as THAT user (no root), and the file manager is jailed to their home.
// uid/gid of 0 means "root shell" and is only given to admins when
// cfg.adminGetsRootShell is true.
async function assignPlatformIdentity(user) {
  const { execFile } = require('child_process');
  const home = `/home/${user.username}`;
  const idOut = await new Promise((resolve) => {
    execFile('id', ['-u', user.username], (err, so) => resolve(err ? null : parseInt(so.trim(), 10)));
  });
  if (idOut === null || Number.isNaN(idOut)) {
    const created = await new Promise((resolve) => {
      execFile('useradd', ['-m', '-s', '/bin/bash', user.username], (err, so, se) => {
        if (!err) return resolve(true);
        if (/already exists/i.test(se || '')) return resolve(true);
        resolve(false);
      });
    });
    if (!created) return null;
  }
  const ids = await new Promise((resolve) => {
    execFile('id', ['-u', user.username], (e1, uidOut) => {
      execFile('id', ['-g', user.username], (e2, gidOut) => {
        if (e1 || e2) return resolve(null);
        resolve({ uid: parseInt(uidOut.trim(), 10), gid: parseInt(gidOut.trim(), 10) });
      });
    });
  });
  if (!ids) return null;
  const isRoot = ids.uid === 0;
  user.uid = ids.uid;
  user.gid = ids.gid;
  user.home = home;
  user.platformUser = user.username;
  // role-appropriate shell
  user.shellAccess = isRoot ? 'root' : 'user';
  db.save();
  return user;
}

// passwordless sudo for a tiny, explicit set of read-only commands (optional)
async function grantReadOnlySudo(username) {
  const { execFile } = require('child_process');
  const line = `${username} ALL=(root) NOPASSWD: /usr/bin/systemctl status *, /usr/bin/cat /proc/*, /usr/bin/df, /usr/bin/free, /usr/bin/uptime, /usr/bin/id\n`;
  return new Promise((resolve) => {
    execFile('sh', ['-c', `echo ${JSON.stringify(line)} >> /etc/sudoers.d/panel-readonly`], (err) => resolve(!err));
  });
}

module.exports = {
  hashPassword, verifyPassword, passwordPolicy, passwordScore,
  signAccess, signRefresh, verifyAccess, verifyRefresh,
  createSession, validateSession, validateSessionFromPayload, revokeSession, revokeAllSessions, pruneSessions,
  createApiKey, validateApiKey,
  generateTotpSecret, totpUri, verifyTotp, generateBackupCodes,
  checkBruteForce, recordFailedLogin, recordSuccessLogin,
  csrfToken, verifyCsrf, randomPassword,
  assignPlatformIdentity, grantReadOnlySudo,
};
